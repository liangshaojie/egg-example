#!/bin/sh
wifidog=$(ps | grep -c /usr/bin/wifidog)
if [ $wifidog = 2 ];then
echo "ok"
else
/etc/init.d/wifidog start >/dev/null
fi