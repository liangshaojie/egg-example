const express = require('express'),
    fs = require('fs'),
    https = require('https'),
    path = require('path'),
    peer = require('peer');

let app = express(),
    ExpressPeerServer = peer.ExpressPeerServer,
    privateKey  = fs.readFileSync('./private.pem', 'utf8'),
    certificate = fs.readFileSync('./csr.crt', 'utf8');

app.use('/static', express.static(path.resolve(__dirname, '../public')));
app.get('/', function(req, res, next) { res.send('Hello world!'); });

let server = app.listen(4000, () => {
        console.info('Server started at 4000');
    });

let options = {
    debug: true
};

server.on('connection', function(socket) {
    console.info('connection');
    // console.info('socket:', socket);
});
server.on('disconnection', function(socket) {
    console.info('disconnection');
    // console.info('disconnection id:', socket);
});

let httpsServer = https.createServer({
        key: privateKey,
        cert: certificate
    }, app);
app.use('/api', ExpressPeerServer(httpsServer, options));


httpsServer.listen(4433, () => {
    console.info('Https server started at 443.');
});